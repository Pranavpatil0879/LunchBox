 export interface DeliveryAgent {
  id: number;
  name: string;
  available: boolean;
}