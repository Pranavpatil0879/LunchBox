export interface MenuModel{
    itemId :string,
    name:string,
    description:string,
    price:number,
    restaurantId:string,
    imgurl?:string
}