export interface cartItem{
    userId:number,
    itemId:string,
    section: string;
    itemName:string,
    quantity: number,
    price:number
}